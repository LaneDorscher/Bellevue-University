class MinHeap:
    def __init__(self):
        """
        Initialize your data structure here.
        """
        pass

    def insert(self, element):
        """
        Inserts an element into the heap.
        """
        pass

    def extract_min(self):
        """
        Removes and returns the minimum element from the heap.
        """
        pass

    def get_min(self):
        """
        Returns the minimum element from the heap without removing it.
        """
        pass
