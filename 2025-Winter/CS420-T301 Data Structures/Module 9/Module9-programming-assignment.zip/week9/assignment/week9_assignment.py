class Trie:
    def __init__(self):
        """
        Initialize your data structure here.
        """
        pass

    def insert(self, word):
        """
        Inserts a word into the trie.
        """
        pass

    def search(self, word):
        """
        Returns if the word is in the trie.
        """
        pass

    def startsWith(self, prefix):
        """
        Returns if there is any word in the trie that starts with the given prefix.
        """
        pass
