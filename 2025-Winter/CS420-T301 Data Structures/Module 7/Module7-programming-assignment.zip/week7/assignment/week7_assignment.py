class HashTable:
    def __init__(self, size=100):
        """
        Initialize your data structure here.
        """
        pass

    def put(self, key, value):
        """
        Insert a (key, value) pair into the hash table.
        """
        pass

    def get(self, key):
        """
        Retrieve the value associated with the given key.
        """
        pass

    def remove(self, key):
        """
        Remove the (key, value) pair associated with the given key.
        """
        pass

def is_anagram(s1, s2):
    """
    Check if two strings are anagrams of each other.
    """
    pass
